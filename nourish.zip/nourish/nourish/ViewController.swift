//
//  ViewController.swift
//  nourish
//
//  Created by KP on 2019-01-27.
//  Copyright © 2019 nourish_nwhacks. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIBarPositioningDelegate, UIPopoverPresentationControllerDelegate, CameraVCDelegate {
    
    @IBOutlet weak var mainPinkyImg: UIImageView!
    @IBOutlet weak var statusView: UIView!
    @IBOutlet weak var feedMeButton: UIButton!
    @IBOutlet weak var scanResultView: UIView!
    
    @IBOutlet weak var expLabel: UILabel!
    @IBOutlet weak var healthLabel: UILabel!
    
    @IBOutlet weak var scanResultLabel: UILabel!
    @IBOutlet weak var featureImg1: UIImageView!
    @IBOutlet weak var featureImg2: UIImageView!
    @IBOutlet weak var featureImg3: UIImageView!
    
    @IBOutlet weak var featureLabel1: UILabel!
    @IBOutlet weak var featureLabel2: UILabel!
    @IBOutlet weak var featureLabel3: UILabel!
    @IBOutlet weak var feedToBlinkyButton: UIButton!
    
    var result: Any = {}
    
    var expPoint = 0
    var healthPoint = 50
    
    let healthyColor = UIColor(red:0.44, green:0.72, blue:0.55, alpha:1.0)
    let unhealthyColor = UIColor(red:0.95, green:0.56, blue:0.43, alpha:1.0)
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "NOURISH"
        self.view.backgroundColor = UIColor(red:0.89, green:0.87, blue:0.82, alpha:1.0)
        self.navigationController?.navigationBar.barTintColor = UIColor(red:0.95, green:0.56, blue:0.43, alpha:1.0)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.titleTextAttributes =
            [NSAttributedString.Key.foregroundColor: UIColor.black,
             NSAttributedString.Key.font: UIFont.systemFont(ofSize: 21, weight: UIFont.Weight.light)]
        
        self.statusView.layer.cornerRadius = 5.0
        self.statusView.center = self.view.center
        self.statusView.layer.shadowColor = UIColor.gray.cgColor
        self.statusView.layer.shadowOpacity = 1
        self.statusView.layer.shadowOffset = CGSize.zero
        self.statusView.layer.shadowRadius = 2.0
        
        self.scanResultView.frame = CGRect(origin: CGPoint(x: 35,y :100), size: CGSize(width: self.view.frame.width - 70, height: self.view.frame.height - 130))
        self.scanResultView.layer.cornerRadius = 12.0
        self.scanResultView.layer.shadowColor = UIColor.gray.cgColor
        self.scanResultView.layer.shadowOpacity = 1
        self.scanResultView.layer.shadowOffset = CGSize.zero
        self.scanResultView.layer.shadowRadius = 2.0
        self.scanResultView.alpha = 0
        
        view.bringSubviewToFront(self.scanResultView)
        
        self.feedMeButton.layer.cornerRadius = 5.0;
        self.feedMeButton.layer.backgroundColor = UIColor(red:0.44, green:0.72, blue:0.55, alpha:1.0).cgColor
        self.feedMeButton.setTitle("FEED ME", for: UIControl.State.normal);
        self.feedMeButton.setTitleColor(UIColor.darkGray, for: UIControl.State.normal);
        self.feedMeButton.titleLabel?.textColor = UIColor.black
        
        self.featureLabel1.textColor = UIColor.lightGray
        self.featureLabel2.textColor = UIColor.lightGray
        self.featureLabel3.textColor = UIColor.lightGray
        
        self.feedToBlinkyButton.layer.cornerRadius = 8.0
        self.feedToBlinkyButton.layer.backgroundColor = unhealthyColor.cgColor
        self.feedToBlinkyButton.tintColor = UIColor.darkGray
    }

    func position(for bar: UIBarPositioning) -> UIBarPosition {
        return .topAttached
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let destination = segue.destination as? CameraViewController {
            destination.delegate = self
            destination.modalPresentationStyle = .popover
        }
    }

    func scanResult(_ res: Any) {
        DispatchQueue.main.async { [unowned self] in

            if let dictionary = res as? [String: Any] {
                
                self.result = dictionary
                
                if let name = dictionary["name"] as? String {
                    let label = name.components(separatedBy: ",")[0]
                    self.scanResultLabel.text = label
                }
                
                print(dictionary["suger"]!)
                
                if let sugar = dictionary["suger"] as? Int {
                    if (sugar == 1) {
                        self.featureImg1.image = UIImage.init(named: "sugary")
                        self.featureLabel1.text = "High in sugar"
                    }
                }
                
                if let fat = dictionary["unhealthy_fat"] as? Int {
                    if (fat == 1) {
                        self.featureImg2.image = UIImage.init(named: "highfat")
                        self.featureLabel2.text = "High in fat"
                    } else {
                        self.featureImg1.image = UIImage.init(named: "lowfat")
                        self.featureLabel1.text = "Low in fat"
                    }
                }
                
                if let sodium = dictionary["sodium"] as? Int {
                    if (sodium == 1) {
                        self.featureImg3.image = UIImage.init(named: "salty")
                        self.featureLabel3.text = "High in salt"
                    } else {
                        self.featureImg2.image = UIImage.init(named: "lowfat")
                        self.featureLabel2.text = "Low in salt"
                    }
                }
                
                if let vitamin = dictionary["vitamin"] as? Int {
                    if (vitamin == 1) {
                        self.featureImg2.image = UIImage.init(named: "vitaminspresent")
                        self.featureLabel2.text = "High in vitamins"
                    } else {
                        
                    }
                }
                
                if let protein = dictionary["protein"] as? Int {
                    if (protein == 1) {
                        self.featureImg3.image = UIImage.init(named: "highprotein")
                        self.featureLabel3.text = "Has protein"
                    } else {
                        
                    }
                }
            }
            
            self.scanResultView.alpha = 1
        }
    }
    
    @IBAction func feedMeButtonPressed(_ sender: Any) {
        
    }
    
    @IBAction func scanResultCloseButton(_ sender: Any) {
        self.scanResultView.alpha = 0
    }
    
    @IBAction func feedToBlinkyButtonPressed(_ sender: Any) {
        self.expPoint += 10
        self.expLabel.text = String(self.expPoint)
        
        if let dict = self.result as? [String: Any] {
            if let healthPoints = dict["points"] as? Int {
                self.healthPoint += healthPoints
                self.healthLabel.text = String(self.healthPoint)
            }
        }
        
        if (self.healthPoint < 30) {
            self.mainPinkyImg.image = UIImage.init(named: "sadpinky")
        } else {
            self.mainPinkyImg.image = UIImage.init(named: "happypinky")
        }
        
        self.scanResultView.alpha = 0
    }
}

